define(
"dijit/nls/zh-tw/loading", ({
	loadingState: "載入中...",
	errorState: "抱歉，發生錯誤"
})
);
