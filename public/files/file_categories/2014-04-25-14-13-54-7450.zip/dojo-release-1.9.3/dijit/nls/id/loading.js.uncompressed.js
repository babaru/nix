define(
"dijit/nls/id/loading", ({
	loadingState: "Memuatkan...",
	errorState: "Maaf, terjadi kesalahan"
})
);

