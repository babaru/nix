//>>built
define("dijit/nls/th/loading",({loadingState:"กำลังโหลด...",errorState:"ขออภัย เกิดข้อผิดพลาด"}));
