//>>built
define("dijit/form/nls/el/Textarea",({iframeEditTitle:"περιοχή επεξεργασίας",iframeFocusTitle:"πλαίσιο περιοχής επεξεργασίας"}));
