//>>built
define("dijit/form/nls/zh/ComboBox",({previousMessage:"先前选项",nextMessage:"更多选项"}));
