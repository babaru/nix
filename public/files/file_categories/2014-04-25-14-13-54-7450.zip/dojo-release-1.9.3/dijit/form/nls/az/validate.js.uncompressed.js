define(
"dijit/form/nls/az/validate", ({
	"rangeMessage" : "Bu dəyər aralıq xaricində.",
	"invalidMessage" : "Girilən dəyər keçərli deyil.",
	"missingMessage" : "Bu deyər lazımlı."
})
);
